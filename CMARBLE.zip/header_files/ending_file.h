#pragma once
#include "ending.h"

void open_word(End e[]);
void open_x(End e[]);
void open_y(End e[]);