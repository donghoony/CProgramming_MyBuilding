//
// Created by DongHoony on 2019-12-12.
//
#pragma once
#ifndef CPROGRAMMING_MYBUILDING_BASIC_CONST_H
#define CPROGRAMMING_MYBUILDING_BASIC_CONST_H

#endif //CPROGRAMMING_MYBUILDING_BASIC_CONST_H

#define TRUE 1
#define FALSE 0

#define NOT_OK -1
#define OK 0

#define MAX_TILE 22