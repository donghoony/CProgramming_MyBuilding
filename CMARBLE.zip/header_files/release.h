//
// Created by DongHoony on 2019-12-10.
//

#include "land.h"

#ifndef CPROGRAMMING_MYBUILDING_RELEASE_H
#define CPROGRAMMING_MYBUILDING_RELEASE_H

#endif //CPROGRAMMING_MYBUILDING_RELEASE_H

void release_land(Land* land);
void release_gameboard(Land** gameboard);
void release(Land** gameboard);