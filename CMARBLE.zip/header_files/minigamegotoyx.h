//
// Created by DongHoony on 2019-11-20.
//

#include <windows.h>
#include <stdio.h>
#include "..\\header_files\\gotoyx.h"
//gotoyx.h
//void gotoyx(int y, int x);
//void gotoyx_print(int y, int x, char* arg);
//void gotoyx_set_color(int color);