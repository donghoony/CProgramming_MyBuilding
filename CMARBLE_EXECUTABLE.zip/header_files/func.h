#ifndef CPROGRAMMING_MYBUILDING_FUNC_H
#define CPROGRAMMING_MYBUILDING_FUNC_H

#endif //CPROGRAMMING_MYBUILDING_FUNC_H

int ending_credit();
void play_ending_credit_song();
void ending();